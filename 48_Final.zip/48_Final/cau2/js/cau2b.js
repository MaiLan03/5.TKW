 function lapTop(image) {
     const display = document.getElementById('previewContainer');
     const img = document.getElementById('previewImage');
     // Hiển thị hình ảnh và thông tin
     img.src = './img/' + image + '.jpg

     // Hiển thị khung thông tin
     display.style.display = 'block';
 }
